from PIL import Image, ImageFilter, ImageDraw
import random, math, os

print('ProcBanner 1.0.0 (v1.0.0:edHiNjVh7uBkK0fq, Jun 20 2018, 04:32:01)\nType "help", "copyright", or "credits" for more information.')

while True:
	kbin = input(">>> ").replace(" ", "")
	try:
		if kbin == 'help':
			print("\nWelcome to ProcBanner 1.0.0's help utility!\n")
			print('To begin, you must choose the alignment type. Type "R" for radial,')
			print('"H" for horizontal, or "V" for Verticle. This must be followed by an integer,')
			print('which represents the amount of objects to be created.')
			print('\nType "exit" to quit.\n')
			continue

		if kbin == 'copyright':
			print("\nCopyright (c) 2018 Orion Quick.\nAll Rights Reserved.\n")
			print("More information at https://www.copyrighted.com/work/edHiNjVh7uBkK0fq\n")
			continue

		if kbin == 'credits':
			print("\nSpecial Thanks to Josh Herzler, Donovan Drews,")
			print("Marita Bos, and the rest of my family.\n")
			continue

		if kbin == 'exit':
			break

		align = kbin[0]
		sect = int(kbin[1:])

		while True:
			try:
				canvas = Image.new('RGBA', (Image.open("base.png").size), color = input("Color: "))
				break
			except:
				print("Input color not valid")

		cWidth = 800
		cHeight = 800

		canvas.thumbnail((cWidth, cHeight))

		iWidth = int(150 + 450 / sect)
		iHeight = int(150 + 450 / sect)

		temp = Image.open('Heraldic_Charges\\' + random.choice(os.listdir("Heraldic_Charges\\")))
		temp.thumbnail((iWidth, iHeight))

		img = Image.new('RGBA', (iWidth, iHeight), color = (255, 255, 255, 0))
		img.paste(temp, (int(iWidth/2 - temp.size[0] / 2), int(iHeight/2 - temp.size[1] / 2)), temp)


		center = (int(cWidth / 2 - iWidth / 2), int(cHeight / 2 - iHeight / 2))

		if align == 'R' or align == 'r':
			img.thumbnail((img.size[0], img.size[1]))
			for i in range(0, sect):
				angle = 2*math.pi*i/sect + math.pi/2
				scale = 300 - (300 / sect)
				canvas.paste(img, (center[0] + int(math.cos(angle) * scale), center[1] + int(math.sin(angle) * scale)), img)

		if align == 'H' or align == 'h':
			for i in range(0, sect):
				canvas.paste(img, (int(cWidth * (i + 1) / (sect + 1) - iWidth / 2), center[1]), img)

		if align == 'V' or align == 'v':
			for i in range(0, sect):
				canvas.paste(img, (center[0], int(cHeight * (i + 1) / (sect + 1) - iHeight / 2)), img)

		canvas.paste(Image.open("base.png"), (0, 0), (Image.new('RGBA', (canvas.size), color = (0, 0, 0, 60))))
		canvas.save("Banner.png", "PNG")

		#Display images
		canvas.show()
	except:
		continue
